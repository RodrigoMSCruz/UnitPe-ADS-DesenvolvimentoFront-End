# Prova 2º Unidade - FrontEnd

<div align="center">
<img src="https://user-images.githubusercontent.com/83848231/204631765-aec3b84a-05fc-4403-a508-cfedd4f0aa9f.png" width="300px"/>
</div>

<br>
Menu:  
<ul>
  <li>Tela de Home</li>
  <li>Tela de Login</li>
  <li>Cadastro</li>
  <li>Sessões</li>
  <li>Listagem de Registros</li>
  <li>Edição de Registros</li>
  <li>Exclusão de Registros</li>
  <li>Pesquisa</li>
</ul>

