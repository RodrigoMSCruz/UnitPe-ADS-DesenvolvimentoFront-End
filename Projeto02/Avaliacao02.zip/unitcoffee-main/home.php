<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/stylehome.css">
    <title>Unit Coffee</title>
  </head>
  <body>
    <div class="box">
      <p><img src="img/logo.png" width="400px" height="400px"></p>
      <a href="login.php">Login</a>
      <a href="formulario.php">Cadastre-se</a> 
    </div>
</body>
</html>